<?php
if ( ! defined('PPPHP')) exit('非法入口');
class route
{

	public function route()
	{
		print_r($_SERVER);
	}
}