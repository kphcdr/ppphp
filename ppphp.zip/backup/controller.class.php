<?php
if ( ! defined('PPPHP')) exit('非法入口');
class controller
{
	public function controller()
	{

	}
}