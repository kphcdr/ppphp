<?php
if ( ! defined('PPPHP')) exit('非法入口');
class model
{

	public function model()
	{
		
	}
}