<?php /* Smarty version Smarty-3.1.15, created on 2013-12-01 13:24:54
         compiled from "F:\www\git\ppphp\app\view\test.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24406529ac8269130f9-00867504%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2a07f2e00ba3f88acb5dbd12fee8c3fa4f79aa42' => 
    array (
      0 => 'F:\\www\\git\\ppphp\\app\\view\\test.tpl',
      1 => 1385831872,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24406529ac8269130f9-00867504',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'a' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_529ac8279981a9_30389970',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_529ac8279981a9_30389970')) {function content_529ac8279981a9_30389970($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['a']->value;?>

hello<?php }} ?>
