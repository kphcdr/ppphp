<?php
if ( ! defined('PPPHP')) exit('非法入口');
/*
 *  输入类
 *  用于获取GET POST SERVER
 * 
 * 
 */
class input
{
    public function __construct()
    {
        
    }
    /*
     * 获取GET数据
     */
    public function get($value)
    {
        
    }
    /*
     * 获取POST数据
     */    
    public function post($value)
    {
        
    }
    /*
     * 获取server数据
     */    
    public function server($value)
    {
        
    }
		
}