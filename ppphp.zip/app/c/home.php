<?php
if ( ! defined('PPPHP')) exit('�Ƿ����');

class home extends ppphp 
{
	public function home()
	{
		echo 'home';
	}
}