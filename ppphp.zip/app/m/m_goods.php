<?php
if ( ! defined('PPPHP')) exit('�Ƿ����');
class goods extends model
{
	public function goods()
	{
		//$this->db->where();
	}	
}